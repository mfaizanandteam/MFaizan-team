# CyberSparkAI – AI Learning & Cybersecurity Platform

A Flask educational platform for students, teachers and administrators.

## Features
- Student, teacher and admin accounts with password hashing and role checks.
- AI quiz generation (MCQs and short-answer questions) using Gemini or OpenAI.
- AI summaries of pasted notes and uploaded PDF, DOCX or TXT material.
- AI study assistant grounded in user-provided study material.
- Timed quizzes, automatic MCQ scoring, result review and CSV export.
- Student performance analytics.
- Classroom creation and student join codes.
- Cybersecurity sample library covering CIA triad, phishing, SQL injection, encryption, firewalls and malware.
- Responsive dark technology-inspired interface, About, Terms and Privacy pages.

## Setup
1. Install Python 3.12.
2. Create a virtual environment and activate it.
3. Run `pip install -r requirements.txt`.
4. Copy `.env.example` to `.env`.
5. Set a strong `SECRET_KEY`, choose `AI_PROVIDER=gemini` or `openai`, and provide the corresponding API key.
6. Optional: set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before first launch to create an administrator.
7. Run `python app.py`, then visit http://127.0.0.1:5000.

AI functionality requires a valid provider API key and internet access from the server. Never put API keys in frontend code or commit `.env`.

## Notes
- The local fallback question generator is intentionally basic and is disabled by default. AI-generated content should always be reviewed before publishing.
- MCQ answers are auto-marked. Short-answer questions are provided as study prompts and model answers; they are not automatically graded in this starter.
- Classroom creation and join-code enrollment are implemented. Full assignment scheduling, notifications, attendance and gradebook workflows are future enhancements.
- This is a starter project, not a security-audited production LMS. Add CSRF protection, rate limiting, email verification/password reset, secure cookie settings, backups, logging, monitoring and malware scanning before public deployment.
- The timer is enforced in the browser interface; production exams should also validate start/end timestamps server-side.
