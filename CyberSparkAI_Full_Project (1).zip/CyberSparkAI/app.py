import os, json, csv, io, secrets, re, urllib.request, urllib.error
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from dotenv import load_dotenv

load_dotenv()
app=Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY","change-me-before-deployment"),
    SQLALCHEMY_DATABASE_URI=os.getenv("DATABASE_URL","sqlite:///cybersparkai.db").replace("postgres://","postgresql://"),
    SQLALCHEMY_TRACK_MODIFICATIONS=False, MAX_CONTENT_LENGTH=20*1024*1024,
    UPLOAD_FOLDER=os.path.join(app.root_path,"uploads")
)
os.makedirs(app.config["UPLOAD_FOLDER"],exist_ok=True)
db=SQLAlchemy(app)
serializer=URLSafeTimedSerializer(app.config["SECRET_KEY"])
ALLOWED={"txt","pdf","docx"}

class User(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(100),nullable=False)
    email=db.Column(db.String(160),unique=True,nullable=False,index=True)
    password_hash=db.Column(db.String(255),nullable=False)
    role=db.Column(db.String(20),default="student",nullable=False)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)
class Quiz(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    title=db.Column(db.String(160),nullable=False)
    subject=db.Column(db.String(100),default="General")
    description=db.Column(db.Text,default="")
    questions_json=db.Column(db.Text,nullable=False)
    owner_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False)
    is_public=db.Column(db.Boolean,default=False)
    duration_minutes=db.Column(db.Integer,default=15)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)
    owner=db.relationship("User")
class Attempt(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    quiz_id=db.Column(db.Integer,db.ForeignKey("quiz.id"),nullable=False)
    user_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False)
    score=db.Column(db.Integer,default=0)
    total=db.Column(db.Integer,default=0)
    answers_json=db.Column(db.Text,default="{}")
    created_at=db.Column(db.DateTime,default=datetime.utcnow)
    quiz=db.relationship("Quiz")
    user=db.relationship("User")
class Classroom(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(140),nullable=False)
    subject=db.Column(db.String(100),default="General")
    join_code=db.Column(db.String(12),unique=True,nullable=False)
    teacher_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)
    teacher=db.relationship("User")
class Enrollment(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    classroom_id=db.Column(db.Integer,db.ForeignKey("classroom.id"),nullable=False)
    student_id=db.Column(db.Integer,db.ForeignKey("user.id"),nullable=False)
    classroom=db.relationship("Classroom")
    student=db.relationship("User")
class Assignment(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    classroom_id=db.Column(db.Integer,db.ForeignKey("classroom.id"),nullable=False)
    quiz_id=db.Column(db.Integer,db.ForeignKey("quiz.id"),nullable=False)
    due_at=db.Column(db.DateTime,nullable=True)
    classroom=db.relationship("Classroom")
    quiz=db.relationship("Quiz")

def me(): return db.session.get(User,session.get("uid")) if session.get("uid") else None
@app.context_processor
def common(): return {"current_user":me(),"year":datetime.utcnow().year}
def login_required(fn):
    @wraps(fn)
    def w(*a,**k):
        if not me(): flash("Please sign in first.","warning"); return redirect(url_for("login"))
        return fn(*a,**k)
    return w
def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        @login_required
        def w(*a,**k):
            if me().role not in allowed: abort(403)
            return fn(*a,**k)
        return w
    return deco
def allowed_file(name): return "." in name and name.rsplit(".",1)[1].lower() in ALLOWED
def extract_text(file):
    ext=file.filename.rsplit(".",1)[-1].lower()
    data=file.read()
    if ext=="txt": return data.decode("utf-8",errors="ignore")
    if ext=="pdf":
        try:
            from pypdf import PdfReader
            reader=PdfReader(io.BytesIO(data))
            return "\n".join(p.extract_text() or "" for p in reader.pages)
        except ImportError: raise ValueError("PDF support requires pypdf. Install project requirements.")
    if ext=="docx":
        try:
            from docx import Document
            doc=Document(io.BytesIO(data))
            return "\n".join(p.text for p in doc.paragraphs)
        except ImportError: raise ValueError("DOCX support requires python-docx. Install project requirements.")
    raise ValueError("Unsupported file type.")

def ai_request(prompt,system="You are a careful educational tutor. Be accurate, structured, and state uncertainty."):
    provider=os.getenv("AI_PROVIDER","gemini").lower()
    if provider=="openai":
        key=os.getenv("OPENAI_API_KEY")
        if not key: raise ValueError("Add OPENAI_API_KEY to your environment.")
        payload={"model":os.getenv("OPENAI_MODEL","gpt-4o-mini"),"messages":[{"role":"system","content":system},{"role":"user","content":prompt}],"temperature":0.2}
        req=urllib.request.Request("https://api.openai.com/v1/chat/completions",data=json.dumps(payload).encode(),headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"})
        endpoint="openai"
    else:
        key=os.getenv("GEMINI_API_KEY")
        if not key: raise ValueError("Add GEMINI_API_KEY to your environment.")
        model=os.getenv("GEMINI_MODEL","gemini-2.0-flash")
        payload={"system_instruction":{"parts":[{"text":system}]},"contents":[{"parts":[{"text":prompt}]}],"generationConfig":{"temperature":0.2}}
        req=urllib.request.Request(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",data=json.dumps(payload).encode(),headers={"Content-Type":"application/json"})
        endpoint="gemini"
    try:
        with urllib.request.urlopen(req,timeout=60) as r: result=json.loads(r.read())
    except urllib.error.HTTPError as e:
        detail=e.read().decode(errors="ignore")[:500]
        raise ValueError(f"AI provider error ({e.code}): {detail}")
    if endpoint=="openai": return result["choices"][0]["message"]["content"]
    return result["candidates"][0]["content"]["parts"][0]["text"]

def parse_json(text):
    match=re.search(r"\{.*\}|\[.*\]",text,re.S)
    if not match: raise ValueError("AI response was not valid JSON. Please try again.")
    return json.loads(match.group())

def generate_local_questions(source,count,difficulty,kind="mcq"):
    sentences=[re.sub(r"\s+"," ",s).strip() for s in re.split(r"(?<=[.!?])\s+",source) if len(s.strip())>45]
    out=[]
    for s in sentences[:count]:
        words=re.findall(r"\b[A-Za-z][A-Za-z0-9-]{4,}\b",s)
        if not words: continue
        answer=max(words,key=len)
        q={"question":re.sub(r"\b"+re.escape(answer)+r"\b","________",s,count=1,flags=re.I),"answer":answer,"explanation":s,"difficulty":difficulty,"type":"mcq","options":[answer,"Not mentioned","Incorrect statement","None of these"]}
        out.append(q)
    return out

def make_questions(source,count,difficulty,kind):
    prompt=f"""Create exactly up to {count} accurate questions from ONLY the source text below. Difficulty: {difficulty}. Type: {kind}.
Return JSON only: {{"questions":[{{"question":"...","options":["A","B","C","D"],"answer":"exact option text","explanation":"...","topic":"..."}}]}}.
For short questions, options may be an empty array and answer should be a concise model answer. Do not invent facts.
SOURCE:
{source[:24000]}"""
    try:
        data=parse_json(ai_request(prompt,"You create reliable educational assessments grounded only in supplied material."))
        qs=data.get("questions",[]) if isinstance(data,dict) else data
        clean=[]
        for q in qs[:count]:
            if not q.get("question") or not q.get("answer"): continue
            if kind=="mcq" and (len(q.get("options",[]))<2 or q["answer"] not in q["options"]): continue
            q.setdefault("explanation",""); q.setdefault("topic","General"); q["type"]=kind; q["difficulty"]=difficulty
            clean.append(q)
        if clean: return clean
    except Exception:
        if os.getenv("AI_FALLBACK_LOCAL","false").lower()=="true" and kind=="mcq":
            qs=generate_local_questions(source,count,difficulty)
            if qs: return qs
        raise
    raise ValueError("No valid questions could be generated from this material.")

@app.route("/")
def home():
    quizzes=Quiz.query.filter_by(is_public=True).order_by(Quiz.created_at.desc()).limit(6).all()
    return render_template("home.html",quizzes=quizzes)
@app.route("/about")
def about(): return render_template("about.html")
@app.route("/terms")
def terms(): return render_template("terms.html")
@app.route("/privacy")
def privacy(): return render_template("privacy.html")
@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower(); pw=request.form.get("password","")
        role=request.form.get("role","student")
        if role not in ("student","teacher"): role="student"
        if not name or len(pw)<8 or "@" not in email: flash("Enter valid details; password must be at least 8 characters.","danger")
        elif User.query.filter_by(email=email).first(): flash("Email already registered.","danger")
        else:
            u=User(name=name,email=email,password_hash=generate_password_hash(pw),role=role); db.session.add(u); db.session.commit()
            session["uid"]=u.id; return redirect(url_for("dashboard"))
    return render_template("auth.html",mode="register")
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=User.query.filter_by(email=request.form.get("email","").strip().lower()).first()
        if u and check_password_hash(u.password_hash,request.form.get("password","")):
            session.clear(); session["uid"]=u.id; return redirect(url_for("dashboard"))
        flash("Email or password is incorrect.","danger")
    return render_template("auth.html",mode="login")
@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("home"))
@app.route("/dashboard")
@login_required
def dashboard():
    u=me()
    quizzes=Quiz.query.filter_by(owner_id=u.id).order_by(Quiz.created_at.desc()).all()
    attempts=Attempt.query.filter_by(user_id=u.id).order_by(Attempt.created_at.desc()).limit(10).all()
    if u.role=="admin": stats={"users":User.query.count(),"quizzes":Quiz.query.count(),"attempts":Attempt.query.count()}
    else: stats={}
    return render_template("dashboard.html",quizzes=quizzes,attempts=attempts,stats=stats)
@app.route("/create",methods=["GET","POST"])
@login_required
def create():
    if request.method=="POST":
        source=request.form.get("source","").strip()
        upload=request.files.get("material")
        if upload and upload.filename:
            if not allowed_file(upload.filename): flash("Upload PDF, DOCX or TXT only.","danger"); return redirect(url_for("create"))
            try: source+="\n"+extract_text(upload)
            except Exception as e: flash(str(e),"danger"); return redirect(url_for("create"))
        if len(source)<40: flash("Paste at least 40 characters or upload study material.","warning"); return redirect(url_for("create"))
        try:
            count=max(1,min(40,int(request.form.get("count",10))))
            kind=request.form.get("kind","mcq"); difficulty=request.form.get("difficulty","Mixed")
            qs=make_questions(source,count,difficulty,kind)
            quiz=Quiz(title=request.form.get("title","My Study Quiz")[:160],subject=request.form.get("subject","General")[:100],description="Generated from supplied study material",questions_json=json.dumps(qs),owner_id=me().id,duration_minutes=max(1,min(180,int(request.form.get("duration",15)))))
            db.session.add(quiz); db.session.commit(); flash(f"Generated {len(qs)} draft questions. Review before publishing.","success")
            return redirect(url_for("edit_quiz",qid=quiz.id))
        except Exception as e: flash(str(e),"danger")
    return render_template("create.html")
@app.route("/summarize",methods=["GET","POST"])
@login_required
def summarize():
    result=""
    if request.method=="POST":
        source=request.form.get("source","")
        upload=request.files.get("material")
        if upload and upload.filename:
            try: source+="\n"+extract_text(upload)
            except Exception as e: flash(str(e),"danger")
        if len(source)>30:
            try: result=ai_request("Summarize this study material. Provide: 1) short overview 2) detailed structured summary 3) key terms 4) important takeaways 5) possible exam focus. Do not add unsupported facts.\n\n"+source[:24000])
            except Exception as e: flash(str(e),"danger")
    return render_template("summarize.html",result=result)
@app.route("/assistant",methods=["GET","POST"])
@login_required
def assistant():
    answer=""
    if request.method=="POST":
        source=request.form.get("source","").strip(); question=request.form.get("question","").strip()
        if question:
            prompt=("Answer the student's question using the supplied study material. If the answer is absent, say so clearly. Explain step by step where useful.\nMATERIAL:\n"+source[:18000]+"\nQUESTION:\n"+question)
            try: answer=ai_request(prompt)
            except Exception as e: flash(str(e),"danger")
    return render_template("assistant.html",answer=answer)
@app.route("/cyber")
def cyber():
    samples=[
      ("CIA Triad","The CIA triad is a foundational information security model consisting of confidentiality, integrity, and availability. Confidentiality limits information access to authorized entities. Integrity protects data from unauthorized alteration. Availability ensures systems and data remain accessible when needed."),
      ("Phishing","Phishing is a social engineering attack in which an attacker impersonates a trusted entity to trick a target into revealing sensitive information, opening malicious links, or downloading harmful files. Defensive measures include user awareness, email filtering, multi-factor authentication, and careful URL verification."),
      ("SQL Injection","SQL injection occurs when untrusted input is incorporated into database queries without safe parameterization. Attackers may manipulate query logic to access or alter data. Use parameterized queries, least-privilege database accounts, input validation, and secure error handling."),
      ("Encryption","Encryption transforms readable plaintext into ciphertext using a cryptographic algorithm and key. Decryption reverses the process for authorized users. Strong modern systems use well-reviewed algorithms and protect keys carefully."),
      ("Firewall","A firewall monitors and controls network traffic according to security rules. It can restrict unwanted connections and segment networks, but it should be combined with patching, endpoint protection, monitoring, and secure configuration."),
      ("Malware","Malware is software designed to disrupt, damage, spy on, or gain unauthorized access to systems. Common categories include ransomware, spyware, trojans, worms, and viruses. Defense includes updates, backups, least privilege, endpoint protection, and cautious behavior.")
    ]
    return render_template("cyber.html",samples=samples)
@app.route("/quiz/<int:qid>")
@login_required
def edit_quiz(qid):
    q=Quiz.query.get_or_404(qid)
    if q.owner_id!=me().id and me().role!="admin": abort(403)
    return render_template("edit_quiz.html",quiz=q,questions=json.loads(q.questions_json))
@app.route("/quiz/<int:qid>/save",methods=["POST"])
@login_required
def save_quiz(qid):
    q=Quiz.query.get_or_404(qid)
    if q.owner_id!=me().id and me().role!="admin": abort(403)
    try:
        questions=json.loads(request.form.get("questions_json","[]"))
        if not questions: raise ValueError()
        q.questions_json=json.dumps(questions); q.is_public=request.form.get("public")=="yes"; db.session.commit()
        flash("Quiz saved.","success")
    except Exception: flash("Unable to save quiz.","danger")
    return redirect(url_for("edit_quiz",qid=qid))
@app.route("/quiz/<int:qid>/take",methods=["GET","POST"])
@login_required
def take(qid):
    q=Quiz.query.get_or_404(qid)
    if q.owner_id!=me().id and not q.is_public and me().role!="admin": abort(403)
    questions=json.loads(q.questions_json)
    if request.method=="POST":
        answers={str(i):request.form.get(f"q{i}","") for i in range(len(questions))}
        score=sum(1 for i,x in enumerate(questions) if x.get("type","mcq")=="mcq" and answers[str(i)]==x.get("answer"))
        a=Attempt(quiz_id=q.id,user_id=me().id,score=score,total=sum(1 for x in questions if x.get("type","mcq")=="mcq"),answers_json=json.dumps(answers)); db.session.add(a); db.session.commit()
        return render_template("result.html",quiz=q,questions=questions,answers=answers,score=score)
    return render_template("take.html",quiz=q,questions=questions)
@app.route("/quiz/<int:qid>/delete",methods=["POST"])
@login_required
def delete_quiz(qid):
    q=Quiz.query.get_or_404(qid)
    if q.owner_id!=me().id and me().role!="admin": abort(403)
    Attempt.query.filter_by(quiz_id=q.id).delete(); db.session.delete(q); db.session.commit(); return redirect(url_for("dashboard"))
@app.route("/quiz/<int:qid>/export")
@login_required
def export(qid):
    q=Quiz.query.get_or_404(qid)
    if q.owner_id!=me().id and me().role!="admin": abort(403)
    out=io.StringIO(); w=csv.writer(out); w.writerow(["Question","Options","Answer","Explanation"])
    for x in json.loads(q.questions_json): w.writerow([x["question"]," | ".join(x.get("options",[])),x["answer"],x.get("explanation","")])
    mem=io.BytesIO(out.getvalue().encode("utf-8-sig")); mem.seek(0)
    return send_file(mem,mimetype="text/csv",as_attachment=True,download_name="quiz.csv")
@app.route("/classrooms",methods=["GET","POST"])
@login_required
def classrooms():
    if request.method=="POST":
        action=request.form.get("action")
        if action=="create" and me().role in ("teacher","admin"):
            c=Classroom(name=request.form.get("name","My Class"),subject=request.form.get("subject","General"),join_code=secrets.token_hex(4).upper(),teacher_id=me().id); db.session.add(c); db.session.commit()
        elif action=="join":
            c=Classroom.query.filter_by(join_code=request.form.get("code","").upper()).first()
            if c and not Enrollment.query.filter_by(classroom_id=c.id,student_id=me().id).first(): db.session.add(Enrollment(classroom_id=c.id,student_id=me().id)); db.session.commit()
            else: flash("Class code not found or already joined.","warning")
        elif action=="assign" and me().role in ("teacher","admin"):
            c=Classroom.query.get_or_404(int(request.form.get("classroom_id",0)))
            q=Quiz.query.get_or_404(int(request.form.get("quiz_id",0)))
            if c.teacher_id!=me().id and me().role!="admin": abort(403)
            if q.owner_id!=me().id and me().role!="admin": abort(403)
            due=request.form.get("due_at","").strip()
            due_at=datetime.fromisoformat(due) if due else None
            db.session.add(Assignment(classroom_id=c.id,quiz_id=q.id,due_at=due_at)); db.session.commit()
            flash("Quiz assigned to classroom.","success")
        return redirect(url_for("classrooms"))
    if me().role in ("teacher","admin"): items=Classroom.query.filter_by(teacher_id=me().id).all()
    else: items=[e.classroom for e in Enrollment.query.filter_by(student_id=me().id).all()]
    assignments=Assignment.query.filter(Assignment.classroom_id.in_([c.id for c in items])).all() if items else []
    quizzes=Quiz.query.filter_by(owner_id=me().id).all()
    return render_template("classrooms.html",classrooms=items,assignments=assignments,quizzes=quizzes)
@app.route("/analytics")
@login_required
def analytics():
    attempts=Attempt.query.filter_by(user_id=me().id).order_by(Attempt.created_at.asc()).all()
    labels=[a.created_at.strftime("%d %b") for a in attempts]
    scores=[round(100*a.score/a.total) if a.total else 0 for a in attempts]
    return render_template("analytics.html",labels=json.dumps(labels),scores=json.dumps(scores),attempts=attempts)
@app.route("/admin/users")
@roles("admin")
def admin_users(): return render_template("admin.html",users=User.query.order_by(User.created_at.desc()).all())
@app.route("/admin/role/<int:uid>",methods=["POST"])
@roles("admin")
def role_update(uid):
    u=User.query.get_or_404(uid); role=request.form.get("role")
    if role in ("student","teacher","admin") and u.id!=me().id: u.role=role; db.session.commit()
    return redirect(url_for("admin_users"))
@app.route("/health")
def health(): return jsonify(status="ok",app="CyberSparkAI")
@app.errorhandler(403)
def forbidden(e): return render_template("message.html",title="Access denied",message="You do not have permission to access this page."),403
with app.app_context():
    db.create_all()
    email=os.getenv("ADMIN_EMAIL"); password=os.getenv("ADMIN_PASSWORD")
    if email and password and not User.query.filter_by(email=email.lower()).first():
        db.session.add(User(name="CyberSparkAI Admin",email=email.lower(),password_hash=generate_password_hash(password),role="admin")); db.session.commit()
if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.getenv("PORT",5000)),debug=os.getenv("FLASK_DEBUG","false").lower()=="true")
